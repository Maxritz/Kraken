# The Zen 3 arm: what AVX2 actually does here

This file exists because "AVX2 fallback" was, on the int8 path, not an
optimisation. It was a widening loop that measured the same as scalar, and
anything claiming otherwise was measuring the scalar path.

Zen 3 has no AVX-512. The per-core ceiling is **2x 256-bit FMA3** (FP0 and
FP1), so 8 f32 lanes x 2 ops = 16 MAC/cycle, and a 256-bit vector is the widest
thing that retires at full rate. AVX-512 first appears in Zen 4, where it is
double-pumped and therefore worth about the same throughput with fewer
instructions. So on this hardware class the 256-bit kernel is not a
consolation prize: it is the fast path.

Force the arm on any x86 machine to test it:

```
VNPU_FORCE_ISA=avx2 ./bin/vnpu-selftest
VNPU_FORCE_ISA=avx2 ./build/vnpu-isa-parity
VNPU_FORCE_ISA=avx2 ./build/vnpu-bench-i8
```

## 1. The int8 GEMM

The packed weight layout is `[n_block][k4][16][4]`: for each group of four
k-values, the four multipliers belonging to column `n` sit at `dst[lane*4 + kk]`.
That contiguity is the whole point, and the old kernel did not use it.

```c
/* before: gemm_i8_avx2_tile */
for (; k + 8 <= p.K; k += 8) {
    for (uint32_t j = 0; j < 8; ++j)          /* 8 scalar byte-gathers */
        ((uint8_t*)&bv)[j] = p.B.original[(k+j)*p.B.N + n];
    __m256i a32 = _mm256_cvtepi8_epi32(a8);   /* widen 8 int8 -> 8 int32 */
    __m256i b32 = _mm256_cvtepi8_epi32(b8);
    acc = _mm256_add_epi32(acc, _mm256_mullo_epi32(a32, b32));
}
```

Eight MACs per iteration, paid for with eight scalar loads, two widens and a
32-bit multiply, all serialised through one accumulator. The AVX-512 path
twenty lines below uses `dpbusd` and does 16 MACs per instruction; this did not.

`_mm256_maddubs_epi16` + `_mm256_madd_epi16` does **32 MACs in two
instructions** on the packed layout. The catch is `+128`, the offset the VNNI
path uses to make its first operand unsigned: `dpbusd` accumulates into int32
and absorbs it, but `maddubs` produces int16 and `255 * 127 * 2 = 64770`
overflows that immediately.

So this uses the sign trick instead: the first operand becomes `|a|` and the
second becomes `b * sign(a)`, via `_mm256_sign_epi8`. Peak magnitude is then
`128 * 127 * 2 = 32512`, which fits int16 exactly, and **no correction term is
needed** -- padding is zero on both sides when the weights are packed (see
`vnpu_pack_weights_i8`), and a zero A byte has `|a| = 0`, so it contributes
nothing regardless of what sign it is given.

Result, one core, 768x768 expert matrices (`vnpu-bench-i8`):

| shape | scalar | old avx2 | **new avx2** | old -> new |
|---|---:|---:|---:|---:|
| 1x768x768 (decode row) | 0.358 ms | 0.326 ms | **0.075 ms** | **4.3x** |
| 32x768x768 | 9.456 ms | 8.321 ms | **0.548 ms** | **15.2x** |
| 128x768x768 | 39.735 ms | 30.869 ms | **1.960 ms** | **15.7x** |
| 1x2048x768 (wide K) | 0.956 ms | 0.909 ms | **0.108 ms** | **8.4x** |

**Correction (2026-10-27).** An earlier revision of this file claimed that the
256-bit kernel "outruns the AVX-512 VNNI path" here. It does not. That number
came from `VNPU_FORCE_ISA=avx512`, which stripped the VNNI feature bit and so
ran this same AVX2 kernel on both arms; see npuxl-0003. With VNNI reachable the
AVX-512 kernel is ~4x faster (130 vs 32 GMAC/s, single thread, 128x768x768).
Forcing `avx2` on an AVX-512 host is still legitimate, but not because it wins.

## 2. Per-row int8 quantisation

`quantize_rows` was entirely scalar: one `std::fabs`/`std::max` pass for the
scale, then one `std::round` per element. It is 25.8% of device busy time in the
Kraken W8A8 trace, second only to the GEMM itself, because a quantised model
re-quantises every activation row on every projection.

The vector version is **bit-identical**, deliberately. `quantize_value()` rounds
with `std::round`, which is half-away-from-zero, while `vcvtps2dq` rounds half to
even. Emulating round() costs four instructions (trunc, fractional part, two
compares) and removes a class of "the AVX2 arm and the AVX-512 arm disagree"
reports. The max reduction is exact (max is associative over finite floats), and
a row containing a non-finite value takes the scalar path wholesale.

## 3. Proof that the answers did not move

`tests/isa_parity.cpp` hashes the raw bytes of every kernel output and prints
one digest per op, so the arms can be compared directly:

```
for isa in scalar avx2 avx512; do VNPU_FORCE_ISA=$isa ./build/vnpu-isa-parity; done
```

| op | scalar | avx2 | avx512 |
|---|---|---|---|
| int8 GEMM, all six shapes | `1b1e6304...` etc. | **identical** | **identical** |
| quantize rows / scales | `f4328060...` | **identical** | **identical** |
| add | `10ba4f9d...` | identical | identical |
| f32 GEMM, swiglu | reference | = avx512 | != scalar |
| rmsnorm, softmax | reference | != scalar | != scalar |

Shapes include `767x763` (K not a multiple of 4, N not a multiple of 16),
`4x4x4`, `1x...` decode rows and `33x...` prefill rows, because the padding
edges are where a block kernel breaks and the round numbers never do.

The f32 rows are a **pre-existing** property of this engine, not something these
changes introduced: the vectorised f32 reductions sum in a different order from
the scalar loop, so `VNPU_FORCE_ISA` changes f32 results in the last bits. That
is worth knowing before blaming it on the int8 work, and worth keeping in mind
if a deployment pins results across a mixed fleet.

## 4. End to end, in an engine

Kraken, 2 GiB q8_0 MoE fixture, 121-token prompt, `KRK_NPU_W8A8=1`, best of 3:

| arm | prefill before | prefill after | decode before | decode after |
|---|---:|---:|---:|---:|
| avx2 (Zen 3 forced) | 13271.4 ms | **3446.9 ms (3.85x)** | 233.4 ms | **42.8 ms (5.5x)** |
| avx512 (default) | 2974.5 ms | 2940.5 ms | 29.6 ms | 24.9 ms |

The baseline AVX2 number was within 1% of the scalar arm, which is the point:
before this change, a Zen 3 user enabling int8 weights got scalar speed and no
reason to know it. The prefill hash is unchanged (`fc8a5598db7ec9cd` on both),
so the 3.85x costs no accuracy.

The AVX-512 arm did not regress -- the VNNI path was not touched.
