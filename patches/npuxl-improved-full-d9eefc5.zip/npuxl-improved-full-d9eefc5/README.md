# npuxl-improved

A virtual NPU: a small, dependency-free library that presents an accelerator's
command interface — device, streams, command batches, packed weights, traces —
and implements the handful of transformer operators it exposes on top of the
host CPU's SIMD units. It runs on x86-64 (SSE2 baseline, AVX2, AVX-512 with
VNNI) and on ARM (NEON). There is no accelerator requirement, so a GPU-less
machine can exercise a real offload path, and a machine with one can compare.

The point is not to beat a real accelerator on throughput. It is to have a
device-shaped seam that behaves like a device: queues work, packs weights once,
runs per-ISA kernels, reports what it did, and can be forced onto a specific
instruction set so that comparisons mean something.

## Building

```
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j
```

CMake 3.16+, a C++17 compiler, pthreads. No other dependencies. `make` also
works and drops binaries in `bin/` + `lib/`; CMake puts them in `build/`.

Compiling is deliberately conservative: no `-march=native`. Every SIMD routine
carries its own `__attribute__((target(...)))`, and dispatch picks one at
runtime from `__builtin_cpu_supports`. A binary built here therefore runs
anywhere, and an AVX-512 kernel cannot leak into code that a Zen 3 machine will
execute.

## The ISA arms

| `VNPU_FORCE_ISA` | ISA | VNNI | Notes |
|---|---|---|---|
| *(unset)* | detected | detected | what you want |
| `scalar` | scalar | no | the reference arm; the correctness oracle |
| `avx2` | AVX2+FMA | no | Zen 3 and anything pre-Skylake-era |
| `avx512` | AVX-512 | **kept if the host has it** | |
| `avx512-novnni` | AVX-512 | no | to isolate the VNNI instruction |

Forcing an ISA the host cannot execute is **refused by name** — it prints why
and keeps the detected ISA, rather than executing an illegal instruction. That
matters on exactly the machines the flag is most tempting on: an AVX2-only host
asked for `avx512` used to fault inside the first kernel.

### Zen 3 has no AVX-512, and that is fine

Zen 3 has two 256-bit FMA3 pipes per core; AVX-512 arrives with Zen 4, where it
is double-pumped and buys roughly the same throughput in fewer instructions. So
the 256-bit path is the fast path on that hardware, not a fallback. The AVX2
int8 GEMM is written accordingly: `maddubs` + `madd_epi16` over the packed
`[n_block][k4][16][4]` layout, 32 MACs in two instructions.

It uses `|a| * (b * sign(a))` rather than the `+128` bias trick the VNNI path
uses, because `maddubs` produces int16 and `255 * 127 * 2` overflows it. The
peak magnitude is then `128 * 127 * 2 = 32512`, which fits, and **no correction
term is needed**: the packer zeroes its padding on both K and N, and a zero A
byte has `|a| = 0`.

## Measured

Microkernel only — `vnpu-bench-kernel`, one tile, one worker, so this excludes
tile construction, pool dispatch and the barrier. 128x768x768 int8 GEMM, the
shape of a routed expert matrix in a 768-wide MoE:

| arm | time | MAC/s | vs scalar |
|---|---:|---:|---:|
| `scalar` | 64.602 ms | 1,169 | 1.0x |
| `avx2` (Zen 3) | 5.894 ms | 12,808 | **11.0x** |
| `avx512-novnni` | 5.905 ms | 12,785 | 11.0x |
| `avx512` (VNNI) | 1.042 ms | 72,429 | **62.0x** |

`avx512-novnni` matching `avx2` is not a bug: without VNNI the same 256-bit
kernel is used, because `dpbusd` is what makes the 512-bit version worth having.

Through the public API (`vnpu_matmul_i8`, both pool threads, best of N):

| shape | scalar | avx2 | avx512 (VNNI) |
|---|---:|---:|---:|
| 1x768x768 (decode row) | 0.298 ms | 0.062 ms | 0.096 ms |
| 32x768x768 | 8.505 ms | 0.901 ms | 0.287 ms |
| 128x768x768 | 32.885 ms | 3.999 ms | 0.938 ms |
| 256x768x768 | 66.477 ms | 6.778 ms | 1.921 ms |

At decode shapes the fixed cost of a dispatch is comparable to the GEMM itself,
which is why the M=1 row is not the 4x the microkernel shows — the kernel is
4.2x faster there (0.022 vs 0.091 ms) but the call around it is not free. Use
the microkernel table for kernel claims and this one for what a single call
costs.

## Verifying

`VNPU_FORCE_ISA` exists so arms can be compared, so there is a test that
compares them **exactly** rather than within a tolerance:

```
for isa in scalar avx2 avx512 avx512-novnni; do
    VNPU_FORCE_ISA=$isa ./build/vnpu-isa-parity
done
```

It hashes the raw output bytes of each operator and prints a digest per op.
The int8 GEMM and the int8 quantiser must print **identical digests on every
arm**, including the awkward shapes (K not a multiple of 4, N not a multiple of
16, `4x4x4`, decode rows, prefill rows), because the padding edges are where a
block kernel breaks and round numbers never are.

The f32 reductions (RMSNorm, softmax, f32 GEMM, SwiGLU) do **not** match the
scalar arm: the vectorised versions sum in a different order. That is a real
property of this library, worth knowing before pinning results across a mixed
fleet, and it is reported rather than hidden.

```
./build/vnpu-selftest          # 16 tests; expect 0 failures on every arm
./build/vnpu-fuzz 60           # randomized shapes/units/culling
```

## Layout

```
include/vnpu.h        the public C API
src/core/runtime.cpp  device lifecycle, streams, events, CPU detection, tracing
src/core/scheduler.cpp  command execution
src/core/autotune.cpp tile-size search
src/kernels/kernels.cpp SIMD GEMM (f32 and int8), per-ISA, runtime-dispatched
src/kernels/llm.cpp     RMSNorm, softmax, RoPE, SwiGLU, GELU, attention, quantise
src/cluster/          multi-node
tests/                parity, benchmarks, shape fuzzer
docs/ZEN3-AVX2.md     the AVX2 int8 kernel in detail
```

## A note on the committed binaries

`lib/libvnpu.a` and `lib/libvnpu.so` are tracked in git. They are build output:
toolchain- and glibc-specific. If you are linking this library, **build it from
source** and point at your own `build/` or re-run `make`; a prebuilt object from
someone else's machine is a link error waiting for a different glibc. They are
kept in the tree because some consumers vendor the archive directly.

## History worth knowing

Two defects were fixed that had been silently distorting every benchmark taken
with this library:

- `VNPU_FORCE_ISA=avx512` cleared the VNNI feature bit, routing the int8 GEMM
  to the AVX2 kernel. Anyone comparing arms — which is what the flag is for —
  was measuring AVX2 and calling it AVX-512: 20,304 vs 82,395 MAC/s, 4.1x,
  with nothing in the output saying which kernel ran.
- The VNNI kernel multiplied its scales in the opposite order from the scalar
  oracle, `(dot*sb)*sa` against `(dot*sa)*sb`. Commutative, not associative, so
  it differed in the last bit and was the only arm that disagreed with the
  reference. `vnpu-isa-parity` caught it the moment VNNI became reachable,
  which is the case that test was written for.
