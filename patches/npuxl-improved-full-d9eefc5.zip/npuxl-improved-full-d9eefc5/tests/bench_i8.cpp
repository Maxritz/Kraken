/*
 * bench_i8.cpp - int8 GEMM throughput at the shapes an MoE expert actually has.
 *
 * The number this exists to produce: MAC/s on the packed int8 kernel, per ISA.
 * Run it for each arm and compare:
 *
 *     for isa in scalar avx2 avx512; do
 *         VNPU_FORCE_ISA=$isa ./build/vnpu-bench-i8
 *     done
 *
 * Shapes are the ones Kraken asks for: a routed expert is a 768x768 matrix
 * (gate, up, down all the same width in the bench fixture), fed one row per
 * decode step and a whole block of rows per prefill chunk. Both are measured
 * because they stress different things -- M=1 is bound by the B stream, M=128
 * by the multiply -- and a kernel that only wins at one of them is not a win
 * for a real run.
 */
#include "vnpu.h"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <vector>

namespace {

uint32_t rng_state = 0x9e3779b9u;
int8_t rnd_i8() {
    rng_state ^= rng_state << 13;
    rng_state ^= rng_state >> 17;
    rng_state ^= rng_state << 5;
    return static_cast<int8_t>(static_cast<int>(rng_state % 255) - 127);
}

double now_ms() {
    using clock = std::chrono::steady_clock;
    return std::chrono::duration<double, std::milli>(
               clock::now().time_since_epoch())
        .count();
}

}  // namespace

int main() {
    vnpu_config_t cfg;
    vnpu_config_init(&cfg);
    cfg.node_name = "bench-i8";
    vnpu_device_t *device = nullptr;
    vnpu_stream_t *stream = nullptr;
    if (vnpu_device_create(&cfg, &device) != VNPU_OK ||
        vnpu_stream_create(device, 0, &stream) != VNPU_OK) {
        std::fprintf(stderr, "bench: failed to create runtime\n");
        return 1;
    }

    vnpu_device_info_t info{};
    vnpu_device_get_info(device, &info);
    const char *name = info.name;

    const struct { uint32_t M, K, N; const char *what; } shapes[] = {
        {1, 768, 768, "decode expert row"},
        {32, 768, 768, "prefill 32 rows"},
        {128, 768, 768, "prefill 128 rows"},
        {256, 768, 768, "prefill 256 rows"},
        {1, 2048, 768, "decode wide-K"},
    };

    std::printf("bench-i8  device=%s\n", name);
    std::printf("%-20s %6s %6s %6s %10s %10s %10s\n", "shape", "M", "K", "N",
                "best ms", "MAC/s", "GFLOP/s");
    for (const auto &sh : shapes) {
        const uint32_t M = sh.M, K = sh.K, N = sh.N;
        std::vector<int8_t> A(static_cast<size_t>(M) * K);
        std::vector<int8_t> B(static_cast<size_t>(K) * N);
        std::vector<float> scale_a(M, 1.0f), scales_b(N, 1.0f);
        std::vector<float> C(static_cast<size_t>(M) * N, 0.0f);
        for (auto &v : A) v = rnd_i8();
        for (auto &v : B) v = rnd_i8();

        vnpu_packed_weights_t *packed = nullptr;
        if (vnpu_pack_weights_i8(device, B.data(), scales_b.data(), K, N, 0, 0,
                                 &packed) != VNPU_OK) {
            std::fprintf(stderr, "bench: pack failed\n");
            return 1;
        }
        vnpu_matmul_i8_args_t args{};
        args.A = A.data();
        args.B = packed;
        args.scale_a = scale_a.data();
        args.C = C.data();
        args.M = M;
        args.K = K;
        args.N = N;
        args.epilogue = VNPU_EPILOGUE_NONE;
        args.unit = VNPU_UNIT_VOODOO;

        /* Warm, then best of N: the first call pays page faults on C. */
        for (int i = 0; i < 3; ++i) vnpu_matmul_i8(stream, &args);
        double best = 1e30;
        const int reps = M <= 32 ? 60 : (M <= 128 ? 20 : 10);
        for (int i = 0; i < reps; ++i) {
            const double t0 = now_ms();
            vnpu_matmul_i8(stream, &args);
            best = std::min(best, now_ms() - t0);
        }
        const double macs = static_cast<double>(M) * K * N;
        std::printf("%-20s %6u %6u %6u %10.3f %10.2f %10.2f\n", sh.what, M, K,
                    N, best, macs / (best / 1000.0) / 1e6,
                    macs * 2.0 / (best / 1000.0) / 1e9);
        vnpu_packed_weights_destroy(packed);
    }
    vnpu_stream_destroy(stream);
    vnpu_device_destroy(device);
    return 0;
}
