/*
 * bench_kernel.cpp - the int8 GEMM microkernel on its own.
 *
 * The public bench (bench_i8) measures vnpu_matmul_i8, which is tile
 * construction, a thread-pool dispatch, a barrier and the kernel. When that
 * number will not move, the question is whether the kernel is slow or whether
 * everything around it is -- and the public API cannot tell you.
 *
 * This calls kernel_gemm_i8_range directly with one tile covering the whole
 * matrix and one worker, so the number is the microkernel and nothing else.
 *
 *     VNPU_FORCE_ISA=avx512 ./build/vnpu-bench-kernel
 *
 * What it prints is MAC/s for a set of shapes plus the ratio to the same
 * workload scalar-summed on the spot, which is the honest ceiling on what the
 * arithmetic can do versus what the memory system allows.
 */
#include "internal.h"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <vector>

namespace {

double now_ms() {
    using clock = std::chrono::steady_clock;
    return std::chrono::duration<double, std::milli>(
               clock::now().time_since_epoch())
        .count();
}

}  // namespace

int main() {
    vnpu_config_t cfg;
    vnpu_config_init(&cfg);
    cfg.node_name = "bench-kernel";
    vnpu_device_t *device = nullptr;
    if (vnpu_device_create(&cfg, &device) != VNPU_OK) {
        std::fprintf(stderr, "bench-kernel: device create failed\n");
        return 1;
    }

    std::printf("bench-kernel  isa=%u  vnni=%d  single worker, one tile\n",
                device->cpu.isa, device->has_vnni() ? 1 : 0);

    const struct { uint32_t M, K, N; } shapes[] = {
        {1, 768, 768}, {32, 768, 768}, {128, 768, 768}, {256, 768, 768},
        {128, 512, 512},
    };

    std::printf("%-22s %10s %12s %10s\n", "shape", "best ms", "MAC/s", "GFLOP/s");
    for (const auto &sh : shapes) {
        const uint32_t M = sh.M, K = sh.K, N = sh.N;
        std::vector<int8_t> A(static_cast<size_t>(M) * K);
        std::vector<int8_t> Bm(static_cast<size_t>(K) * N);
        std::vector<float> scale_a(M, 1.0f);
        std::vector<float> scales_b(N, 1.0f);
        std::vector<float> C(static_cast<size_t>(M) * N, 0.0f);
        for (size_t i = 0; i < A.size(); ++i)
            A[i] = static_cast<int8_t>((i * 37 + 11) % 255 - 127);
        for (size_t i = 0; i < Bm.size(); ++i)
            Bm[i] = static_cast<int8_t>((i * 53 + 7) % 255 - 127);

        vnpu_packed_weights_t *packed = nullptr;
        if (vnpu_pack_weights_i8(device, Bm.data(), scales_b.data(), K, N, 0, 0,
                                 &packed) != VNPU_OK) {
            std::fprintf(stderr, "bench-kernel: pack failed\n");
            return 1;
        }

        vnpu::GemmI8Params p;
        p.A = A.data();
        p.scale_a = scale_a.data();
        p.C = C.data();
        p.M = M;
        p.K = K;
        p.N = N;
        p.lda = K;
        p.ldc = N;
        p.epilogue = VNPU_EPILOGUE_NONE;
        p.unit = VNPU_UNIT_VOODOO;
        p.isa = device->cpu.isa;
        p.has_vnni = device->has_vnni();
        p.B.packed = packed->packed.data();
        p.B.original = packed->original.data();
        p.B.scales = packed->scales.data();
        p.B.column_sums = packed->column_sums.data();
        p.B.K = packed->K;
        p.B.N = packed->N;
        p.B.Kpad = packed->Kpad;
        p.B.Npad = packed->Npad;
        p.B.packed_bytes = packed->packed.size();

        /* One tile over the whole matrix: no tiling effects, no culling. */
        std::vector<vnpu::TileJob> tiles;
        vnpu::TileJob t{};
        t.m0 = 0;
        t.n0 = 0;
        t.tm = M;
        t.tn = N;
        t.tile_m = M;
        t.tile_n = N;
        t.tile_k = K;
        t.cull = 0;
        tiles.push_back(t);
        p.tiles = &tiles;

        std::vector<std::vector<uint8_t>> stores(1);
        stores[0].resize(VNPU_LOCAL_STORE_BYTES + VNPU_CACHELINE_BYTES);
        p.local_stores = &stores;
        p.local_store_bytes = VNPU_LOCAL_STORE_BYTES;

        for (int i = 0; i < 3; ++i) vnpu::kernel_gemm_i8_range(p, 0, 1, 0);
        double best = 1e30;
        const int reps = M <= 32 ? 60 : (M <= 128 ? 20 : 10);
        for (int i = 0; i < reps; ++i) {
            const double t0 = now_ms();
            vnpu::kernel_gemm_i8_range(p, 0, 1, 0);
            best = std::min(best, now_ms() - t0);
        }
        const double macs = static_cast<double>(M) * K * N;
        char label[32];
        std::snprintf(label, sizeof(label), "%ux%ux%u", M, K, N);
        std::printf("%-22s %10.3f %12.2f %10.2f\n", label, best,
                    macs / (best / 1000.0) / 1e6,
                    macs * 2.0 / (best / 1000.0) / 1e9);
        vnpu_packed_weights_destroy(packed);
    }
    vnpu_device_destroy(device);
    return 0;
}
