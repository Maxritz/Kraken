/*
 * isa_parity.cpp - do the ISA arms agree, bit for bit?
 *
 * Why this exists: the AVX2 (Zen 3 class) kernels and the AVX-512 kernels take
 * different routes to the same dot products, and on top of that each route has
 * its own rounding. A tolerance-based test cannot tell "the AVX2 path is
 * correct" from "the AVX2 path is off by an amount the tolerance happens to
 * cover", and the failure this is really looking for -- a wrong lane order in a
 * pack, a stale sign mask, an accumulator read one block early -- produces
 * plausible numbers that happen to be wrong. So this compares BYTES.
 *
 * Run it once per ISA and compare the digests:
 *
 *     for isa in scalar avx2 avx512; do
 *         VNPU_FORCE_ISA=$isa ./bin/vnpu-isa-parity
 *     done
 *
 * Every arm must print the same digest. The scalar arm is the reference by
 * construction (it is the loop the others are supposed to reproduce), and the
 * other two are held to it exactly.
 *
 * What is covered: int8 GEMM against packed weights (the kernel this test was
 * written for), per-row int8 quantisation, f32 GEMM, RMSNorm, softmax, SwiGLU,
 * and elementwise add -- i.e. the set of ops an engine actually calls per
 * layer. Shapes are deliberately awkward (K not a multiple of 4, N not a
 * multiple of 16, M = 1 decode rows and M = 17 prefill rows) because the block
 * kernels have edges there and the pretty shapes are the ones that never fail.
 */
#include "vnpu.h"

#include <cmath>
#include <cstdio>
#include <cstring>
#include <vector>

namespace {

/* FNV-1a over bytes. Deterministic, dependency-free, and short enough that a
 * mismatch is obvious on sight. */
struct Digest {
    uint64_t h = 0xcbf29ce484222325ull;
    void bytes(const void *p, size_t n) {
        const unsigned char *b = static_cast<const unsigned char *>(p);
        for (size_t i = 0; i < n; ++i) {
            h ^= static_cast<uint64_t>(b[i]);
            h *= 0x100000001b3ull;
        }
    }
    template <typename T>
    void value(const T &v) {
        bytes(&v, sizeof(v));
    }
};

uint64_t rng_state = 0x243f6a8885a308d3ull;
uint32_t xs() {
    uint64_t x = rng_state;
    x ^= x << 13;
    x ^= x >> 7;
    x ^= x << 17;
    rng_state = x;
    return static_cast<uint32_t>(x >> 16);
}
float rnd() {
    return static_cast<float>(static_cast<int>(xs() % 2001) - 1000) / 1000.0f;
}
int8_t rnd_i8() {
    return static_cast<int8_t>(static_cast<int>(xs() % 255) - 127);
}

}  // namespace

int main() {
    vnpu_config_t cfg;
    vnpu_config_init(&cfg);
    cfg.node_name = "parity";
    vnpu_device_t *device = nullptr;
    vnpu_stream_t *stream = nullptr;
    if (vnpu_device_create(&cfg, &device) != VNPU_OK ||
        vnpu_stream_create(device, 0, &stream) != VNPU_OK) {
        std::fprintf(stderr, "parity: failed to create runtime\n");
        return 1;
    }

    Digest d;
    int failures = 0;
    auto report = [](const char *what, const Digest &g) {
        std::printf("  %-22s %016llx\n", what,
                    static_cast<unsigned long long>(g.h));
    };
    (void)report;

    /* ---- int8 GEMM over packed weights -------------------------------- */
    /* (M, K, N) chosen for the edges: K%4 != 0 exercises the k4 padding, N%16
     * != 0 the column padding, M=1 the decode shape, M=17 the prefill shape. */
    const struct { uint32_t M, K, N; } shapes[] = {
        {1, 768, 768},   {17, 768, 768}, {1, 767, 763},
        {17, 767, 763},  {4, 4, 4},      {33, 1024, 2048},
    };
    for (const auto &sh : shapes) {
        const uint32_t M = sh.M, K = sh.K, N = sh.N;
        std::vector<int8_t> A(static_cast<size_t>(M) * K);
        std::vector<int8_t> B(static_cast<size_t>(K) * N);
        std::vector<float> scale_a(M), scales_b(N), bias(N);
        std::vector<float> C(static_cast<size_t>(M) * N, 0.0f);
        for (auto &v : A) v = rnd_i8();
        for (auto &v : B) v = rnd_i8();
        for (auto &v : scale_a) v = 0.001f + std::fabs(rnd()) * 0.01f;
        for (auto &v : scales_b) v = 0.001f + std::fabs(rnd()) * 0.01f;
        for (auto &v : bias) v = rnd();

        vnpu_packed_weights_t *packed = nullptr;
        if (vnpu_pack_weights_i8(device, B.data(), scales_b.data(), K, N,
                                 /*ldb=*/0, /*trans_b=*/0, &packed) != VNPU_OK ||
            !packed) {
            std::fprintf(stderr, "parity: pack failed\n");
            return 1;
        }
        vnpu_matmul_i8_args_t args{};
        args.A = A.data();
        args.B = packed;
        args.scale_a = scale_a.data();
        args.bias = bias.data();
        args.C = C.data();
        args.M = M;
        args.K = K;
        args.N = N;
        args.lda = 0;
        args.ldc = 0;
        args.epilogue = VNPU_EPILOGUE_NONE;
        args.unit = VNPU_UNIT_VOODOO;
        if (vnpu_matmul_i8(stream, &args) != VNPU_OK) {
            std::fprintf(stderr, "parity: matmul_i8 failed (%ux%ux%u)\n", M, K,
                         N);
            return 1;
        }
        {
            Digest g;
            g.bytes(C.data(), C.size() * sizeof(float));
            std::printf("  i8gemm %ux%ux%u        %016llx\n", M, K, N,
                        static_cast<unsigned long long>(g.h));
        }
        d.bytes(C.data(), C.size() * sizeof(float));
        vnpu_packed_weights_destroy(packed);
    }

    /* ---- per-row int8 quantisation ------------------------------------ */
    {
        const uint32_t rows = 7, cols = 300;
        std::vector<float> X(static_cast<size_t>(rows) * cols);
        std::vector<int8_t> Y(X.size(), 0);
        std::vector<float> sc(rows, 0.0f);
        for (auto &v : X) v = rnd() * 3.0f;
        /* Force the half-way case std::round and vcvtps2dq disagree on: every
         * 16th element is exactly half a quantum. */
        for (uint32_t r = 0; r < rows; ++r) {
            X[static_cast<size_t>(r) * cols] = 4.0f;
            for (uint32_t j = 0; j + 16 < cols; j += 16)
                X[static_cast<size_t>(r) * cols + j] += 0.5f * 4.0f / 127.0f;
        }
        vnpu_quantize_i8_args_t q{};
        q.X = X.data();
        q.Y = Y.data();
        q.scales = sc.data();
        q.rows = rows;
        q.cols = cols;
        q.axis = VNPU_QUANT_PER_ROW;
        q.unit = VNPU_UNIT_VOODOO;
        if (vnpu_quantize_i8(stream, &q) != VNPU_OK) {
            std::fprintf(stderr, "parity: quantize failed\n");
            return 1;
        }
        {
            Digest g;
            g.bytes(Y.data(), Y.size());
            std::printf("  quant rows           %016llx\n",
                        static_cast<unsigned long long>(g.h));
            Digest g2;
            g2.bytes(sc.data(), sc.size() * sizeof(float));
            std::printf("  quant scales         %016llx\n",
                        static_cast<unsigned long long>(g2.h));
        }
        d.bytes(Y.data(), Y.size());
        d.bytes(sc.data(), sc.size() * sizeof(float));
    }

    /* ---- f32 GEMM ----------------------------------------------------- */
    {
        const uint32_t M = 9, K = 130, N = 70;
        std::vector<float> A(static_cast<size_t>(M) * K);
        std::vector<float> B(static_cast<size_t>(K) * N);
        std::vector<float> C(static_cast<size_t>(M) * N, 0.0f);
        for (auto &v : A) v = rnd();
        for (auto &v : B) v = rnd();
        vnpu_matmul_f32_args_t m{};
        m.A = A.data();
        m.B = B.data();
        m.C = C.data();
        m.M = M;
        m.K = K;
        m.N = N;
        m.alpha = 1.0f;
        m.beta = 0.0f;
        m.unit = VNPU_UNIT_VOODOO;
        if (vnpu_matmul_f32(stream, &m) != VNPU_OK) {
            std::fprintf(stderr, "parity: matmul_f32 failed\n");
            return 1;
        }
        {
            Digest g;
            g.bytes(C.data(), C.size() * sizeof(float));
            std::printf("  f32gemm              %016llx\n",
                        static_cast<unsigned long long>(g.h));
        }
        d.bytes(C.data(), C.size() * sizeof(float));
    }

    /* ---- RMSNorm, softmax, SwiGLU, add -------------------------------- */
    {
        const uint32_t rows = 5, cols = 100;
        std::vector<float> X(static_cast<size_t>(rows) * cols);
        std::vector<float> W(cols), Y(X.size(), 0.0f), Z(X.size(), 0.0f);
        for (auto &v : X) v = rnd() * 2.0f;
        for (auto &v : W) v = 0.5f + std::fabs(rnd());

        vnpu_rmsnorm_f32_args_t rn{};
        rn.X = X.data();
        rn.W = W.data();
        rn.Y = Y.data();
        rn.rows = rows;
        rn.cols = cols;
        rn.eps = 1e-5f;
        rn.unit = VNPU_UNIT_VOODOO;
        if (vnpu_rmsnorm_f32(stream, &rn) != VNPU_OK) {
            std::fprintf(stderr, "parity: rmsnorm failed\n");
            return 1;
        }
        {
            Digest g;
            g.bytes(Y.data(), Y.size() * sizeof(float));
            std::printf("  rmsnorm              %016llx\n",
                        static_cast<unsigned long long>(g.h));
        }
        d.bytes(Y.data(), Y.size() * sizeof(float));

        vnpu_softmax_f32_args_t sm{};
        sm.X = X.data();
        sm.Y = Z.data();
        sm.rows = rows;
        sm.cols = cols;
        sm.unit = VNPU_UNIT_VOODOO;
        if (vnpu_softmax_f32(stream, &sm) != VNPU_OK) {
            std::fprintf(stderr, "parity: softmax failed\n");
            return 1;
        }
        {
            Digest g;
            g.bytes(Z.data(), Z.size() * sizeof(float));
            std::printf("  softmax              %016llx\n",
                        static_cast<unsigned long long>(g.h));
        }
        d.bytes(Z.data(), Z.size() * sizeof(float));

        /* SwiGLU reads gate and up, writes silu(gate) * up. */
        vnpu_swiglu_f32_args_t sg{};
        sg.gate = X.data();
        sg.up = X.data();
        sg.Y = Y.data();
        sg.count = static_cast<uint64_t>(X.size());
        sg.alpha = 1.0f;
        sg.unit = VNPU_UNIT_VOODOO;
        if (vnpu_swiglu_f32(stream, &sg) != VNPU_OK) {
            std::fprintf(stderr, "parity: swiglu failed\n");
            return 1;
        }
        {
            Digest g;
            g.bytes(Y.data(), Y.size() * sizeof(float));
            std::printf("  swiglu               %016llx\n",
                        static_cast<unsigned long long>(g.h));
        }
        d.bytes(Y.data(), Y.size() * sizeof(float));

        vnpu_binary_f32_args_t ad{};
        ad.A = X.data();
        ad.B = X.data();
        ad.Y = Z.data();
        ad.count = static_cast<uint64_t>(X.size());
        ad.alpha = 1.0f;
        ad.beta = 1.0f;
        ad.unit = VNPU_UNIT_VOODOO;
        if (vnpu_add_f32(stream, &ad) != VNPU_OK) {
            std::fprintf(stderr, "parity: add failed\n");
            return 1;
        }
        {
            Digest g;
            g.bytes(Z.data(), Z.size() * sizeof(float));
            std::printf("  add                  %016llx\n",
                        static_cast<unsigned long long>(g.h));
        }
        d.bytes(Z.data(), Z.size() * sizeof(float));
    }

    std::printf("isa_parity digest=%016llx\n",
                static_cast<unsigned long long>(d.h));
    vnpu_stream_destroy(stream);
    vnpu_device_destroy(device);
    return failures == 0 ? 0 : 1;
}
