/*
 * kernels.cpp - SIMD GEMM microkernels.
 *
 * Every ISA-specific routine is runtime-dispatched.  The translation unit is
 * compiled with conservative baseline flags; GCC/Clang target attributes
 * enable AVX2/AVX512 code only inside the marked functions.
 */
#include "../internal.h"

#if VNPU_X86 && (defined(__GNUC__) || defined(__clang__))
#  define VNPU_TARGET_AVX2   __attribute__((target("avx2,fma")))
#  define VNPU_TARGET_AVX512 __attribute__((target("avx512f,avx512bw,avx512dq,avx512vl,avx512vnni,fma")))
#  define VNPU_TARGET_VNNI   __attribute__((target("avx512f,avx512bw,avx512dq,avx512vl,avx512vnni")))
#else
#  define VNPU_TARGET_AVX2
#  define VNPU_TARGET_AVX512
#  define VNPU_TARGET_VNNI
#endif

namespace vnpu {
namespace {

inline const float *a_ptr(const GemmF32Params &p, uint32_t m, uint32_t k)
{
    if (p.trans_a) return p.A + static_cast<size_t>(k) * p.lda + m;
    return p.A + static_cast<size_t>(m) * p.lda + k;
}

inline const float *b_ptr(const GemmF32Params &p, uint32_t k, uint32_t n)
{
    if (p.trans_b) return p.B + static_cast<size_t>(n) * p.ldb + k;
    return p.B + static_cast<size_t>(k) * p.ldb + n;
}

inline float load_a(const GemmF32Params &p, uint32_t m, uint32_t k)
{
    if (p.trans_a) return p.A[static_cast<size_t>(k) * p.lda + m];
    return p.A[static_cast<size_t>(m) * p.lda + k];
}

inline float load_b(const GemmF32Params &p, uint32_t k, uint32_t n)
{
    if (p.trans_b) return p.B[static_cast<size_t>(n) * p.ldb + k];
    return p.B[static_cast<size_t>(k) * p.ldb + n];
}

inline void store_c(const GemmF32Params &p, uint32_t m, uint32_t n, float value)
{
    float *dst = p.C + static_cast<size_t>(m) * p.ldc + n;
    float out = p.alpha * value;
    if (p.bias) out += p.bias[n];
    if (p.beta != 0.0f) out += p.beta * *dst;
    *dst = apply_epilogue(out, p.epilogue);
}

void zero_c_tile(const GemmF32Params &p, const TileJob &tile)
{
    for (uint32_t m = tile.m0; m < tile.m0 + tile.tm; ++m) {
        float *row = p.C + static_cast<size_t>(m) * p.ldc + tile.n0;
        for (uint32_t n = 0; n < tile.tn; ++n) {
            float out = p.bias ? p.bias[tile.n0 + n] : 0.0f;
            if (p.beta != 0.0f) out += p.beta * row[n];
            row[n] = apply_epilogue(out, p.epilogue);
        }
    }
}

/* Portable scalar path - also the correctness oracle. */
void gemm_f32_scalar_tile(const GemmF32Params &p, const TileJob &tile)
{
    for (uint32_t m = tile.m0; m < tile.m0 + tile.tm; ++m) {
        for (uint32_t n = tile.n0; n < tile.n0 + tile.tn; ++n) {
            float acc = 0.0f;
            for (uint32_t k = 0; k < p.K; ++k)
                acc += load_a(p, m, k) * load_b(p, k, n);
            store_c(p, m, n, acc);
        }
    }
}

#if VNPU_X86
VNPU_TARGET_AVX2
static inline float hsum256_ps(__m256 v)
{
    __m128 lo = _mm256_castps256_ps128(v);
    __m128 hi = _mm256_extractf128_ps(v, 1);
    __m128 sum = _mm_add_ps(lo, hi);
    sum = _mm_hadd_ps(sum, sum);
    sum = _mm_hadd_ps(sum, sum);
    return _mm_cvtss_f32(sum);
}

/* B is row-major KxN: accumulate 4 rows x 8 columns in registers. */
VNPU_TARGET_AVX2
static void gemm_f32_avx2_nn_tile(const GemmF32Params &p, const TileJob &tile)
{
    constexpr uint32_t MR = 4;
    constexpr uint32_t NR = 8;
    const uint32_t mend = tile.m0 + tile.tm;
    const uint32_t nend = tile.n0 + tile.tn;
    uint32_t m = tile.m0;
    for (; m + MR <= mend; m += MR) {
        uint32_t n = tile.n0;
        for (; n + NR <= nend; n += NR) {
            __m256 acc0 = _mm256_setzero_ps();
            __m256 acc1 = _mm256_setzero_ps();
            __m256 acc2 = _mm256_setzero_ps();
            __m256 acc3 = _mm256_setzero_ps();
            const float *a0 = a_ptr(p, m + 0, 0);
            const float *a1 = a_ptr(p, m + 1, 0);
            const float *a2 = a_ptr(p, m + 2, 0);
            const float *a3 = a_ptr(p, m + 3, 0);
            if (p.trans_a) {
                gemm_f32_scalar_tile(p, TileJob{m, n, MR, NR,
                                                tile.tile_m, tile.tile_n,
                                                tile.tile_k, 0, {0, 0, 0}});
                continue;
            }
            for (uint32_t k = 0; k < p.K; ++k) {
                __m256 bv = _mm256_loadu_ps(p.B +
                    static_cast<size_t>(k) * p.ldb + n);
                acc0 = _mm256_fmadd_ps(_mm256_set1_ps(a0[k]), bv, acc0);
                acc1 = _mm256_fmadd_ps(_mm256_set1_ps(a1[k]), bv, acc1);
                acc2 = _mm256_fmadd_ps(_mm256_set1_ps(a2[k]), bv, acc2);
                acc3 = _mm256_fmadd_ps(_mm256_set1_ps(a3[k]), bv, acc3);
            }
            float tmp[MR][NR];
            _mm256_storeu_ps(tmp[0], acc0);
            _mm256_storeu_ps(tmp[1], acc1);
            _mm256_storeu_ps(tmp[2], acc2);
            _mm256_storeu_ps(tmp[3], acc3);
            for (uint32_t i = 0; i < MR; ++i)
                for (uint32_t j = 0; j < NR; ++j)
                    store_c(p, m + i, n + j, tmp[i][j]);
        }
        if (n < nend) {
            TileJob tail{m, n, MR, nend - n, tile.tile_m, tile.tile_n,
                         tile.tile_k, 0, {0, 0, 0}};
            gemm_f32_scalar_tile(p, tail);
        }
    }
    if (m < mend) {
        TileJob tail{m, tile.n0, mend - m, tile.tn, tile.tile_m,
                     tile.tile_n, tile.tile_k, 0, {0, 0, 0}};
        gemm_f32_scalar_tile(p, tail);
    }
}

/* B is NxK: vectorized dot product over K for each output element. */
VNPU_TARGET_AVX2
static void gemm_f32_avx2_nt_tile(const GemmF32Params &p, const TileJob &tile)
{
    const uint32_t mend = tile.m0 + tile.tm;
    const uint32_t nend = tile.n0 + tile.tn;
    for (uint32_t m = tile.m0; m < mend; ++m) {
        const float *arow = a_ptr(p, m, 0);
        for (uint32_t n = tile.n0; n < nend; ++n) {
            const float *brow = p.B + static_cast<size_t>(n) * p.ldb;
            __m256 acc = _mm256_setzero_ps();
            uint32_t k = 0;
            for (; k + 8 <= p.K; k += 8) {
                __m256 av = _mm256_loadu_ps(arow + k);
                __m256 bv = _mm256_loadu_ps(brow + k);
                acc = _mm256_fmadd_ps(av, bv, acc);
            }
            float dot = hsum256_ps(acc);
            for (; k < p.K; ++k) dot += arow[k] * brow[k];
            store_c(p, m, n, dot);
        }
    }
}

VNPU_TARGET_AVX512
static inline float hsum512_ps(__m512 v)
{
    float tmp[16];
    /* memcpy avoids a GCC 14 + ASan bug with AVX512 stores to stack arrays. */
    std::memcpy(tmp, &v, sizeof(v));
    float sum = 0.0f;
    for (float x : tmp) sum += x;
    return sum;
}

VNPU_TARGET_AVX512
static void gemm_f32_avx512_nn_tile(const GemmF32Params &p,
                                    const TileJob &tile)
{
    constexpr uint32_t MR = 4;
    constexpr uint32_t NR = 16;
    const uint32_t mend = tile.m0 + tile.tm;
    const uint32_t nend = tile.n0 + tile.tn;
    uint32_t m = tile.m0;
    for (; m + MR <= mend; m += MR) {
        uint32_t n = tile.n0;
        for (; n + NR <= nend; n += NR) {
            __m512 acc0 = _mm512_setzero_ps();
            __m512 acc1 = _mm512_setzero_ps();
            __m512 acc2 = _mm512_setzero_ps();
            __m512 acc3 = _mm512_setzero_ps();
            const float *a0 = a_ptr(p, m + 0, 0);
            const float *a1 = a_ptr(p, m + 1, 0);
            const float *a2 = a_ptr(p, m + 2, 0);
            const float *a3 = a_ptr(p, m + 3, 0);
            if (p.trans_a) {
                gemm_f32_scalar_tile(p, TileJob{m, n, MR, NR,
                                                tile.tile_m, tile.tile_n,
                                                tile.tile_k, 0, {0, 0, 0}});
                continue;
            }
            for (uint32_t k = 0; k < p.K; ++k) {
                __m512 bv = _mm512_loadu_ps(p.B +
                    static_cast<size_t>(k) * p.ldb + n);
                acc0 = _mm512_fmadd_ps(_mm512_set1_ps(a0[k]), bv, acc0);
                acc1 = _mm512_fmadd_ps(_mm512_set1_ps(a1[k]), bv, acc1);
                acc2 = _mm512_fmadd_ps(_mm512_set1_ps(a2[k]), bv, acc2);
                acc3 = _mm512_fmadd_ps(_mm512_set1_ps(a3[k]), bv, acc3);
            }
            float tmp[MR][NR];
            std::memcpy(tmp[0], &acc0, sizeof(acc0));
            std::memcpy(tmp[1], &acc1, sizeof(acc1));
            std::memcpy(tmp[2], &acc2, sizeof(acc2));
            std::memcpy(tmp[3], &acc3, sizeof(acc3));
            for (uint32_t i = 0; i < MR; ++i)
                for (uint32_t j = 0; j < NR; ++j)
                    store_c(p, m + i, n + j, tmp[i][j]);
        }
        if (n < nend) {
            TileJob tail{m, n, MR, nend - n, tile.tile_m, tile.tile_n,
                         tile.tile_k, 0, {0, 0, 0}};
            gemm_f32_scalar_tile(p, tail);
        }
    }
    if (m < mend) {
        TileJob tail{m, tile.n0, mend - m, tile.tn, tile.tile_m,
                     tile.tile_n, tile.tile_k, 0, {0, 0, 0}};
        gemm_f32_scalar_tile(p, tail);
    }
}

VNPU_TARGET_AVX512
static void gemm_f32_avx512_nt_tile(const GemmF32Params &p,
                                    const TileJob &tile)
{
    const uint32_t mend = tile.m0 + tile.tm;
    const uint32_t nend = tile.n0 + tile.tn;
    for (uint32_t m = tile.m0; m < mend; ++m) {
        const float *arow = a_ptr(p, m, 0);
        for (uint32_t n = tile.n0; n < nend; ++n) {
            const float *brow = p.B + static_cast<size_t>(n) * p.ldb;
            __m512 acc = _mm512_setzero_ps();
            uint32_t k = 0;
            for (; k + 16 <= p.K; k += 16) {
                __m512 av = _mm512_loadu_ps(arow + k);
                __m512 bv = _mm512_loadu_ps(brow + k);
                acc = _mm512_fmadd_ps(av, bv, acc);
            }
            float dot = hsum512_ps(acc);
            for (; k < p.K; ++k) dot += arow[k] * brow[k];
            store_c(p, m, n, dot);
        }
    }
}
#endif /* VNPU_X86 */

#if VNPU_NEON
static void gemm_f32_neon_nn_tile(const GemmF32Params &p,
                                  const TileJob &tile)
{
    constexpr uint32_t MR = 4;
    constexpr uint32_t NR = 4;
    const uint32_t mend = tile.m0 + tile.tm;
    const uint32_t nend = tile.n0 + tile.tn;
    uint32_t m = tile.m0;
    for (; m + MR <= mend; m += MR) {
        uint32_t n = tile.n0;
        for (; n + NR <= nend; n += NR) {
            float32x4_t acc0 = vdupq_n_f32(0.0f);
            float32x4_t acc1 = vdupq_n_f32(0.0f);
            float32x4_t acc2 = vdupq_n_f32(0.0f);
            float32x4_t acc3 = vdupq_n_f32(0.0f);
            const float *a0 = a_ptr(p, m + 0, 0);
            const float *a1 = a_ptr(p, m + 1, 0);
            const float *a2 = a_ptr(p, m + 2, 0);
            const float *a3 = a_ptr(p, m + 3, 0);
            for (uint32_t k = 0; k < p.K; ++k) {
                float32x4_t bv = vld1q_f32(p.B +
                    static_cast<size_t>(k) * p.ldb + n);
                acc0 = vfmaq_n_f32(acc0, bv, a0[k]);
                acc1 = vfmaq_n_f32(acc1, bv, a1[k]);
                acc2 = vfmaq_n_f32(acc2, bv, a2[k]);
                acc3 = vfmaq_n_f32(acc3, bv, a3[k]);
            }
            float tmp[MR][NR];
            vst1q_f32(tmp[0], acc0);
            vst1q_f32(tmp[1], acc1);
            vst1q_f32(tmp[2], acc2);
            vst1q_f32(tmp[3], acc3);
            for (uint32_t i = 0; i < MR; ++i)
                for (uint32_t j = 0; j < NR; ++j)
                    store_c(p, m + i, n + j, tmp[i][j]);
        }
        if (n < nend) {
            TileJob tail{m, n, MR, nend - n, tile.tile_m, tile.tile_n,
                         tile.tile_k, 0, {0, 0, 0}};
            gemm_f32_scalar_tile(p, tail);
        }
    }
    if (m < mend) {
        TileJob tail{m, tile.n0, mend - m, tile.tn, tile.tile_m,
                     tile.tile_n, tile.tile_k, 0, {0, 0, 0}};
        gemm_f32_scalar_tile(p, tail);
    }
}
#endif

/* Cell SPE-style path: explicit DMA into an aligned local store followed by
 * register-blocked accumulation.  It deliberately uses a smaller K window so
 * the same code can run on a remote worker with a tiny working set. */
static void gemm_f32_cell_tile(const GemmF32Params &p, const TileJob &tile,
                               uint8_t *scratch, uint64_t scratch_bytes)
{
    uint32_t MR = 4;
    uint32_t NR = (p.isa == ISA_AVX512) ? 16 : 8;
    uint32_t BK = tile.tile_k ? tile.tile_k : 64;
    BK = std::min<uint32_t>(BK, 256);
    const uint64_t a_bytes = static_cast<uint64_t>(MR) * BK * sizeof(float);
    const uint64_t b_bytes = static_cast<uint64_t>(BK) * NR * sizeof(float);
    if (!scratch || a_bytes + b_bytes + 128 > scratch_bytes) {
        gemm_f32_scalar_tile(p, tile);
        return;
    }
    uintptr_t base = reinterpret_cast<uintptr_t>(scratch);
    base = align_up(base, VNPU_CACHELINE_BYTES);
    float *A_s = reinterpret_cast<float *>(base);
    float *B_s = reinterpret_cast<float *>(base + a_bytes);
    const uint32_t mend = tile.m0 + tile.tm;
    const uint32_t nend = tile.n0 + tile.tn;

    for (uint32_t m0 = tile.m0; m0 < mend; m0 += MR) {
        uint32_t rm = std::min<uint32_t>(MR, mend - m0);
        for (uint32_t n0 = tile.n0; n0 < nend; n0 += NR) {
            uint32_t rn = std::min<uint32_t>(NR, nend - n0);
            float acc[4][16] = {};
            for (uint32_t k0 = 0; k0 < p.K; k0 += BK) {
                uint32_t rk = std::min<uint32_t>(BK, p.K - k0);
                /* DMA A panel. */
                for (uint32_t i = 0; i < rm; ++i)
                    for (uint32_t k = 0; k < rk; ++k)
                        A_s[i * BK + k] = load_a(p, m0 + i, k0 + k);
                /* DMA B panel. */
                for (uint32_t k = 0; k < rk; ++k)
                    for (uint32_t j = 0; j < rn; ++j)
                        B_s[k * NR + j] = load_b(p, k0 + k, n0 + j);
                /* SPU local compute. */
                for (uint32_t i = 0; i < rm; ++i) {
                    const float *arow = A_s + i * BK;
                    for (uint32_t k = 0; k < rk; ++k) {
                        float av = arow[k];
                        const float *brow = B_s + k * NR;
                        for (uint32_t j = 0; j < rn; ++j)
                            acc[i][j] += av * brow[j];
                    }
                }
            }
            for (uint32_t i = 0; i < rm; ++i)
                for (uint32_t j = 0; j < rn; ++j)
                    store_c(p, m0 + i, n0 + j, acc[i][j]);
        }
    }
}

static void gemm_f32_dispatch_tile(const GemmF32Params &p,
                                   const TileJob &tile,
                                   uint32_t worker_id)
{
    if (tile.cull) {
        zero_c_tile(p, tile);
        return;
    }
    if (p.unit == VNPU_UNIT_CELL) {
        uint8_t *scratch = nullptr;
        uint64_t bytes = 0;
        if (p.local_stores && worker_id < p.local_stores->size()) {
            scratch = (*p.local_stores)[worker_id].data();
            bytes = (*p.local_stores)[worker_id].size();
        }
        gemm_f32_cell_tile(p, tile, scratch, bytes);
        return;
    }
    if (p.isa == ISA_AVX512 && !p.trans_a) {
        if (!p.trans_b) gemm_f32_avx512_nn_tile(p, tile);
        else gemm_f32_avx512_nt_tile(p, tile);
        return;
    }
    if (p.isa == ISA_AVX2 && !p.trans_a) {
        if (!p.trans_b) gemm_f32_avx2_nn_tile(p, tile);
        else gemm_f32_avx2_nt_tile(p, tile);
        return;
    }
#if VNPU_NEON
    if (p.isa == ISA_NEON && !p.trans_a && !p.trans_b) {
        gemm_f32_neon_nn_tile(p, tile);
        return;
    }
#endif
    gemm_f32_scalar_tile(p, tile);
}

/* ------------------------------------------------------------------------- */
/* INT8 kernels                                                              */
/* ------------------------------------------------------------------------- */

inline void store_i8_c(const GemmI8Params &p, uint32_t m, uint32_t n,
                       int32_t dot)
{
    float scale_a = p.scale_a ? p.scale_a[m] : 1.0f;
    float scale_b = p.B.scales ? p.B.scales[n] : 1.0f;
    float out = static_cast<float>(dot) * scale_a * scale_b;
    if (p.bias) out += p.bias[n];
    p.C[static_cast<size_t>(m) * p.ldc + n] =
        apply_epilogue(out, p.epilogue);
}

static void gemm_i8_scalar_tile(const GemmI8Params &p, const TileJob &tile)
{
    for (uint32_t m = tile.m0; m < tile.m0 + tile.tm; ++m) {
        const int8_t *arow = p.A + static_cast<size_t>(m) * p.lda;
        for (uint32_t n = tile.n0; n < tile.n0 + tile.tn; ++n) {
            int32_t acc = 0;
            for (uint32_t k = 0; k < p.K; ++k)
                acc += static_cast<int32_t>(arow[k]) *
                       static_cast<int32_t>(p.B.original[
                           static_cast<size_t>(k) * p.B.N + n]);
            store_i8_c(p, m, n, acc);
        }
    }
}

#if VNPU_X86
VNPU_TARGET_AVX2
static inline int32_t hsum256_epi32(__m256i v)
{
    int32_t tmp[8];
    _mm256_storeu_si256(reinterpret_cast<__m256i *>(tmp), v);
    int32_t sum = 0;
    for (int32_t x : tmp) sum += x;
    return sum;
}

VNPU_TARGET_AVX2
/* AVX2 int8 GEMM over the packed weight layout (Zen 3 class: two 256-bit FMA
 * pipes, no AVX-512, so 256-bit vectors are the widest thing that runs at full
 * rate).
 *
 * The previous AVX2 tile widened each 8 int8 to int32 and multiplied with
 * mullo_epi32, after gathering the B bytes one at a time out of the row-major
 * copy: 8 MACs per iteration paid for with 8 scalar loads, two vpmovsxbd and a
 * vpmulld, and a serial dependency through one accumulator. On the packed
 * layout the four k-values belonging to one output column are CONTIGUOUS, so
 * maddubs does 32 MACs in one instruction and madd_epi16 folds the pairs.
 *
 * The +128 offset the VNNI path uses to make A unsigned cannot be reused here:
 * dpbusd accumulates straight into int32, but maddubs produces int16 and
 * 255*127*2 = 64770 overflows it. So this uses the sign trick instead -- the
 * first operand becomes |a| (unsigned, <=128) and the second becomes b*sign(a).
 * Max magnitude is then 128*127*2 = 32512, which fits int16 exactly, and no
 * correction term is needed at all: padding is zero on both sides (see
 * vnpu_pack_weights_i8), and a zero A byte has |a| = 0, so it contributes
 * nothing.
 *
 * Requires the packed view. Without it the caller must already have taken the
 * slow widen path, which is kept below for exactly that case. */
VNPU_TARGET_AVX2
static void gemm_i8_avx2_packed_tile(const GemmI8Params &p, const TileJob &tile)
{
    const uint32_t k4_groups = p.B.Kpad / 4;
    const uint32_t mend = tile.m0 + tile.tm;
    const uint32_t nend = std::min<uint32_t>(tile.n0 + tile.tn, p.N);
    const __m256i ones16 = _mm256_set1_epi16(1);
    for (uint32_t m = tile.m0; m < mend; ++m) {
        const int8_t *arow = p.A + static_cast<size_t>(m) * p.lda;
        const float scale_a = p.scale_a ? p.scale_a[m] : 1.0f;
        float *crow = p.C + static_cast<size_t>(m) * p.ldc;
        for (uint32_t n0 = tile.n0; n0 < nend; n0 += 16) {
            const uint8_t *bp = p.B.packed +
                (static_cast<size_t>(n0 / 16) * k4_groups) * 64;
            __m256i acc0 = _mm256_setzero_si256(); /* columns n0+0  .. n0+7  */
            __m256i acc1 = _mm256_setzero_si256(); /* columns n0+8  .. n0+15 */
            for (uint32_t g = 0; g < k4_groups; ++g) {
                const uint32_t kbase = g * 4;
                /* One 4-byte A pattern, broadcast to all 16 columns: the
                 * absolute values, and a sign mask for sign_epi8. */
                uint8_t ab[4], sg[4];
                for (uint32_t j = 0; j < 4; ++j) {
                    const uint32_t k = kbase + j;
                    const int32_t v = k < p.K ? arow[k] : 0;
                    ab[j] = static_cast<uint8_t>(v < 0 ? -v : v);
                    sg[j] = static_cast<uint8_t>(v < 0 ? 0xFF : 0x01);
                }
                int32_t abw, sgw;
                std::memcpy(&abw, ab, sizeof(abw));
                std::memcpy(&sgw, sg, sizeof(sgw));
                const __m256i aabs = _mm256_set1_epi32(abw);
                const __m256i asgn = _mm256_set1_epi32(sgw);
                const uint8_t *b = bp + static_cast<size_t>(g) * 64;
                __m256i b0 = _mm256_sign_epi8(
                    _mm256_loadu_si256(reinterpret_cast<const __m256i *>(b)),
                    asgn);
                __m256i b1 = _mm256_sign_epi8(
                    _mm256_loadu_si256(
                        reinterpret_cast<const __m256i *>(b + 32)),
                    asgn);
                acc0 = _mm256_add_epi32(
                    acc0, _mm256_madd_epi16(
                              _mm256_maddubs_epi16(aabs, b0), ones16));
                acc1 = _mm256_add_epi32(
                    acc1, _mm256_madd_epi16(
                              _mm256_maddubs_epi16(aabs, b1), ones16));
            }
            float out[16];
            const __m256 sa = _mm256_set1_ps(scale_a);
            const __m256 o0 = _mm256_mul_ps(
                _mm256_mul_ps(_mm256_cvtepi32_ps(acc0), sa),
                _mm256_loadu_ps(p.B.scales + n0));
            const __m256 o1 = _mm256_mul_ps(
                _mm256_mul_ps(_mm256_cvtepi32_ps(acc1), sa),
                _mm256_loadu_ps(p.B.scales + n0 + 8));
            std::memcpy(out, &o0, sizeof(o0));
            std::memcpy(out + 8, &o1, sizeof(o1));
            const uint32_t cols = std::min<uint32_t>(16u, nend - n0);
            for (uint32_t j = 0; j < cols; ++j) {
                float v = out[j];
                if (p.bias) v += p.bias[n0 + j];
                crow[n0 + j] = apply_epilogue(v, p.epilogue);
            }
        }
    }
}

/* Fallback for a packed view that is absent: 8 MACs per iteration, kept
 * because a caller may hand the kernel only the row-major copy. */
VNPU_TARGET_AVX2
static void gemm_i8_avx2_flat_tile(const GemmI8Params &p, const TileJob &tile)
{
    for (uint32_t m = tile.m0; m < tile.m0 + tile.tm; ++m) {
        const int8_t *arow = p.A + static_cast<size_t>(m) * p.lda;
        for (uint32_t n = tile.n0; n < tile.n0 + tile.tn; ++n) {
            __m256i acc = _mm256_setzero_si256();
            uint32_t k = 0;
            for (; k + 8 <= p.K; k += 8) {
                uint64_t av = 0, bv = 0;
                std::memcpy(&av, arow + k, sizeof(av));
                for (uint32_t j = 0; j < 8; ++j)
                    reinterpret_cast<uint8_t *>(&bv)[j] =
                        static_cast<uint8_t>(p.B.original[
                            static_cast<size_t>(k + j) * p.B.N + n]);
                __m128i a8 = _mm_loadl_epi64(
                    reinterpret_cast<const __m128i *>(&av));
                __m128i b8 = _mm_loadl_epi64(
                    reinterpret_cast<const __m128i *>(&bv));
                __m256i a32 = _mm256_cvtepi8_epi32(a8);
                __m256i b32 = _mm256_cvtepi8_epi32(b8);
                acc = _mm256_add_epi32(acc, _mm256_mullo_epi32(a32, b32));
            }
            int32_t dot = hsum256_epi32(acc);
            for (; k < p.K; ++k)
                dot += static_cast<int32_t>(arow[k]) *
                       static_cast<int32_t>(p.B.original[
                           static_cast<size_t>(k) * p.B.N + n]);
            store_i8_c(p, m, n, dot);
        }
    }
}

static void gemm_i8_avx2_tile(const GemmI8Params &p, const TileJob &tile)
{
    /* The packed kernel walks whole 16-column blocks and needs the four k of a
     * group; anything else takes the flat path, which has no such requirement. */
    if (p.B.packed && p.B.Kpad >= p.K && (tile.n0 & 15u) == 0) {
        gemm_i8_avx2_packed_tile(p, tile);
        return;
    }
    gemm_i8_avx2_flat_tile(p, tile);
}

/* AVX512-VNNI: A is int8 + 128 (u8), B is signed int8 in [16][4] blocks.
 * The extra 128*sum(B) term is removed with precomputed column sums. */
VNPU_TARGET_VNNI
static inline __m512i make_vnni_avec(const int8_t *row, uint32_t K,
                                     uint32_t kbase)
{
    uint8_t ab[4];
    for (uint32_t j = 0; j < 4; ++j) {
        int16_t v = (kbase + j < K)
            ? static_cast<int16_t>(row[kbase + j]) + 128
            : 128;
        ab[j] = static_cast<uint8_t>(v);
    }
    uint32_t aword;
    std::memcpy(&aword, ab, sizeof(aword));
    return _mm512_set1_epi32(static_cast<int>(aword));
}

VNPU_TARGET_VNNI
static void gemm_i8_vnni_tile(const GemmI8Params &p, const TileJob &tile,
                              uint8_t *scratch, uint64_t scratch_bytes)
{
    constexpr uint32_t MR = 4;
    constexpr uint32_t NB = 4; /* process 64 output columns per tile pass */
    if (tile.n0 & 15u) {
        gemm_i8_scalar_tile(p, tile);
        return;
    }
    const uint32_t k4_groups = p.B.Kpad / 4;
    const uint32_t mend = tile.m0 + tile.tm;
    const uint32_t nend = std::min<uint32_t>(tile.n0 + tile.tn, p.N);
    const uint64_t avec_bytes = static_cast<uint64_t>(MR) *
                                k4_groups * 64;
    /* Precomputing broadcast A vectors pays off only for large GEMMs; small
     * decode-shaped calls are faster with on-the-fly construction. */
    bool precompute = scratch && scratch_bytes >= avec_bytes + 64 &&
                      p.K >= 512 && (nend - tile.n0) >= 256;
    __m512i *Avec = nullptr;
    if (precompute) {
        uintptr_t aligned = align_up(
            reinterpret_cast<uintptr_t>(scratch), VNPU_CACHELINE_BYTES);
        Avec = reinterpret_cast<__m512i *>(aligned);
    }
    for (uint32_t m0 = tile.m0; m0 < mend; m0 += MR) {
        uint32_t rm = std::min<uint32_t>(MR, mend - m0);
        const int8_t *arow[MR] = {};
        for (uint32_t i = 0; i < rm; ++i)
            arow[i] = p.A + static_cast<size_t>(m0 + i) * p.lda;
        if (precompute) {
            for (uint32_t i = 0; i < rm; ++i) {
                for (uint32_t g = 0; g < k4_groups; ++g) {
                    __m512i v = make_vnni_avec(arow[i], p.K, g * 4);
                    std::memcpy(Avec + static_cast<size_t>(i) *
                                          k4_groups + g,
                                &v, sizeof(v));
                }
            }
        }
        for (uint32_t n0 = tile.n0; n0 < nend; n0 += 16 * NB) {
            uint32_t nb = std::min<uint32_t>(
                NB, (nend - n0 + 15u) / 16u);
            const uint8_t *bp[NB] = {};
            uint32_t counts[NB] = {};
            for (uint32_t b = 0; b < nb; ++b) {
                uint32_t col = n0 + 16 * b;
                bp[b] = p.B.packed +
                    (static_cast<size_t>(col / 16) * k4_groups) * 64;
                counts[b] = std::min<uint32_t>(16u, nend - col);
            }
            __m512i acc[MR][NB];
            for (uint32_t i = 0; i < MR; ++i)
                for (uint32_t b = 0; b < NB; ++b)
                    acc[i][b] = _mm512_setzero_si512();
            for (uint32_t g = 0; g < k4_groups; ++g) {
                __m512i bvec[NB];
                for (uint32_t b = 0; b < nb; ++b)
                    bvec[b] = _mm512_loadu_si512(
                        reinterpret_cast<const void *>(bp[b] + g * 64));
                uint32_t kbase = g * 4;
                for (uint32_t i = 0; i < rm; ++i) {
                    __m512i avec;
                    if (precompute) {
                        avec = _mm512_loadu_si512(
                            reinterpret_cast<const void *>(
                                Avec + static_cast<size_t>(i) *
                                           k4_groups + g));
                    } else {
                        avec = make_vnni_avec(arow[i], p.K, kbase);
                    }
#if defined(__GNUC__) && !defined(__clang__)
#pragma GCC unroll 4
#endif
                    for (uint32_t b = 0; b < nb; ++b)
                        acc[i][b] = _mm512_dpbusd_epi32(
                            acc[i][b], avec, bvec[b]);
                }
            }
            float tmp[16];
            for (uint32_t b = 0; b < nb; ++b) {
                uint32_t col = n0 + 16 * b;
                __m512i sums = _mm512_loadu_si512(
                    reinterpret_cast<const void *>(p.B.column_sums + col));
                __m512i corr = _mm512_slli_epi32(sums, 7);
                __m512 scalesb = _mm512_loadu_ps(p.B.scales + col);
                for (uint32_t i = 0; i < rm; ++i) {
                    acc[i][b] = _mm512_sub_epi32(acc[i][b], corr);
                    __m512 dotsf = _mm512_cvtepi32_ps(acc[i][b]);
                    __m512 scalea = _mm512_set1_ps(
                        p.scale_a ? p.scale_a[m0 + i] : 1.0f);
                    /* (dot * scale_a) * scale_b, in that order, because that
                     * is what store_i8_c() does and float multiplication is
                     * commutative but not associative. Multiplying the scales
                     * the other way round is mathematically identical and
                     * differs in the last bit, which is enough to make this
                     * kernel the only arm that disagrees with the scalar
                     * oracle -- caught by vnpu-isa-parity the first time VNNI
                     * was actually reachable (it is not, if VNPU_FORCE_ISA
                     * strips the VNNI bit; see runtime.cpp). */
                    __m512 out = _mm512_mul_ps(
                        _mm512_mul_ps(dotsf, scalea), scalesb);
                    std::memcpy(tmp, &out, sizeof(out));
                    for (uint32_t j = 0; j < counts[b]; ++j) {
                        float value = tmp[j];
                        if (p.bias) value += p.bias[col + j];
                        p.C[static_cast<size_t>(m0 + i) * p.ldc + col + j] =
                            apply_epilogue(value, p.epilogue);
                    }
                }
            }
        }
    }
}
#endif /* VNPU_X86 */

static void gemm_i8_cell_tile(const GemmI8Params &p, const TileJob &tile,
                              uint8_t *scratch, uint64_t scratch_bytes)
{
    uint32_t MR = 4;
    uint32_t NR = 16;
    uint32_t BK = std::min<uint32_t>(tile.tile_k ? tile.tile_k : 64, 256);
    const uint64_t a_bytes = static_cast<uint64_t>(MR) * BK;
    const uint64_t b_bytes = static_cast<uint64_t>(BK) * NR;
    if (!scratch || a_bytes + b_bytes + 128 > scratch_bytes) {
        gemm_i8_scalar_tile(p, tile);
        return;
    }
    uintptr_t base = align_up(reinterpret_cast<uintptr_t>(scratch),
                              VNPU_CACHELINE_BYTES);
    int8_t *A_s = reinterpret_cast<int8_t *>(base);
    int8_t *B_s = reinterpret_cast<int8_t *>(base + a_bytes);
    const uint32_t mend = tile.m0 + tile.tm;
    const uint32_t nend = tile.n0 + tile.tn;
    for (uint32_t m0 = tile.m0; m0 < mend; m0 += MR) {
        uint32_t rm = std::min<uint32_t>(MR, mend - m0);
        for (uint32_t n0 = tile.n0; n0 < nend; n0 += NR) {
            uint32_t rn = std::min<uint32_t>(NR, nend - n0);
            int32_t acc[4][16] = {};
            for (uint32_t k0 = 0; k0 < p.K; k0 += BK) {
                uint32_t rk = std::min<uint32_t>(BK, p.K - k0);
                for (uint32_t i = 0; i < rm; ++i)
                    std::memcpy(A_s + i * BK,
                                p.A + static_cast<size_t>(m0 + i) *
                                          p.lda + k0,
                                rk);
                for (uint32_t k = 0; k < rk; ++k)
                    for (uint32_t j = 0; j < rn; ++j)
                        B_s[k * NR + j] = p.B.original[
                            static_cast<size_t>(k0 + k) * p.B.N + n0 + j];
                for (uint32_t i = 0; i < rm; ++i)
                    for (uint32_t k = 0; k < rk; ++k) {
                        int32_t av = A_s[i * BK + k];
                        for (uint32_t j = 0; j < rn; ++j)
                            acc[i][j] += av *
                                static_cast<int32_t>(B_s[k * NR + j]);
                    }
            }
            for (uint32_t i = 0; i < rm; ++i)
                for (uint32_t j = 0; j < rn; ++j)
                    store_i8_c(p, m0 + i, n0 + j, acc[i][j]);
        }
    }
}

static void gemm_i8_dispatch_tile(const GemmI8Params &p,
                                  const TileJob &tile,
                                  uint32_t worker_id)
{
    if (tile.cull) {
        for (uint32_t m = tile.m0; m < tile.m0 + tile.tm; ++m)
            for (uint32_t n = tile.n0; n < tile.n0 + tile.tn; ++n)
                store_i8_c(p, m, n, 0);
        return;
    }
    if (p.unit == VNPU_UNIT_CELL) {
        uint8_t *scratch = nullptr;
        uint64_t bytes = 0;
        if (p.local_stores && worker_id < p.local_stores->size()) {
            scratch = (*p.local_stores)[worker_id].data();
            bytes = (*p.local_stores)[worker_id].size();
        }
        gemm_i8_cell_tile(p, tile, scratch, bytes);
        return;
    }
#if VNPU_X86
    if (p.has_vnni && p.isa == ISA_AVX512) {
        uint8_t *scratch = nullptr;
        uint64_t bytes = 0;
        if (p.local_stores && worker_id < p.local_stores->size()) {
            scratch = (*p.local_stores)[worker_id].data();
            bytes = (*p.local_stores)[worker_id].size();
        }
        gemm_i8_vnni_tile(p, tile, scratch, bytes);
        return;
    }
    if (p.isa == ISA_AVX2 || p.isa == ISA_AVX512) {
        gemm_i8_avx2_tile(p, tile);
        return;
    }
#endif
    gemm_i8_scalar_tile(p, tile);
}

} /* anonymous namespace */

void kernel_gemm_f32_range(const GemmF32Params &p, size_t begin, size_t end,
                           uint32_t worker_id)
{
    if (!p.tiles) return;
    for (size_t i = begin; i < end; ++i)
        gemm_f32_dispatch_tile(p, (*p.tiles)[i], worker_id);
}

void kernel_gemm_i8_range(const GemmI8Params &p, size_t begin, size_t end,
                          uint32_t worker_id)
{
    if (!p.tiles) return;
    for (size_t i = begin; i < end; ++i)
        gemm_i8_dispatch_tile(p, (*p.tiles)[i], worker_id);
}

} /* namespace vnpu */
